document.getElementById("cbox_module").style.display = "none";
document.getElementById("challengeGenreRanking").style.display = "none";
document.getElementById("rateRanking").style.display = "none";
document.getElementById("newTitleRanking").style.display = "none";
