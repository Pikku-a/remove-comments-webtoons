document.getElementById("_bottomDisplay").style.display = "none";
document.getElementById("challengeRoundUp").style.display = "none";