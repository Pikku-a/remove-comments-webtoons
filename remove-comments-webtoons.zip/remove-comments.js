//document.getElementById("_bottomDisplay").style.display = "none";
//document.getElementById("challengeRoundUp").style.display = "none";

document.getElementById("cbox_module").style.display = "none";
document.getElementById("newTitleRanking").style.display = "none";
document.getElementById("genreRanking").style.display = "none";
document.getElementById("rateRanking").style.display = "none";